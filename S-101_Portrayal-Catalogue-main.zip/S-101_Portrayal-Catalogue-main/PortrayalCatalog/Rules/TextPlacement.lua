-- TextPlacement portrayal rules file.

-- Main entry point for feature type.
function TextPlacement(feature, featurePortrayal, contextParameters)
	error('Not Implemented: No symbology defined in S-52 for TextPlacement')
end
